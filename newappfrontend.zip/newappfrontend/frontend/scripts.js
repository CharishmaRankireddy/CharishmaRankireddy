// scripts.js

document.addEventListener('DOMContentLoaded', function() {
  const notesList = document.getElementById('notesList');
  const addNoteForm = document.getElementById('addNoteForm');
  const noteTitleInput = document.getElementById('noteTitle');
  const noteContentInput = document.getElementById('noteContent');
  const noteIdInput = document.getElementById('noteId');
  const addNoteButton = document.getElementById('addNoteButton');
  const updateNoteButton = document.getElementById('updateNoteButton');
  const deleteNoteButton = document.getElementById('deleteNoteButton');
  const cancelEditButton = document.getElementById('cancelEditButton');

  let editingNoteId = null;

  // Function to fetch and display notes
  function fetchNotes() {
    fetch('/api/notes') // Replace with your backend API endpoint
      .then(response => response.json())
      .then(data => {
        notesList.innerHTML = ''; // Clear existing notes
        data.forEach(note => {
          const noteCard = document.createElement('div');
          noteCard.classList.add('card');

          const cardBody = document.createElement('div');
          cardBody.classList.add('card-body', 'd-flex', 'justify-content-between');

          const title = document.createElement('h5');
          title.classList.add('card-title');
          title.textContent = note.title;

          const content = document.createElement('p');
          content.classList.add('card-text');
          content.textContent = note.content;

          const btnGroup = document.createElement('div');
          btnGroup.classList.add('btn-group');

          const editButton = document.createElement('button');
          editButton.classList.add('btn', 'btn-primary');
          editButton.textContent = 'Edit';
          editButton.addEventListener('click', () => editNoteForm(note));

          const deleteButton = document.createElement('button');
          deleteButton.classList.add('btn', 'btn-danger');
          deleteButton.textContent = 'Delete';
          deleteButton.addEventListener('click', () => deleteNoteConfirm(note.id));

          cardBody.appendChild(title);
          cardBody.appendChild(content);
          btnGroup.appendChild(editButton);
          btnGroup.appendChild(deleteButton);
          cardBody.appendChild(btnGroup);

          noteCard.appendChild(cardBody);
          notesList.appendChild(noteCard);
        });
      })
      .catch(error => console.error('Error fetching notes:', error));
  }

  // Function to handle form submission for adding/updating notes
  addNoteForm.addEventListener('submit', function(event) {
    event.preventDefault();

    const title = noteTitleInput.value;
    const content = noteContentInput.value;

    if (!title || !content) {
      alert('Please enter both title and content.');
      return;
    }

    const formData = {
      title,
      content
    };

    if (editingNoteId) {
      updateNote(formData);
    } else {
      addNote(formData);
    }
  });

  // Function to add a new note
  function addNote(formData) {
    fetch('/api/notes', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(() => {
      fetchNotes();
      resetForm();
    })
    .catch(error => console.error('Error adding note:', error));
  }

  // Function to update an existing note
  function updateNote(formData) {
    fetch(`/api/notes/${editingNoteId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(() => {
      fetchNotes();
      resetForm();
    })
    .catch(error => console.error('Error updating note:', error));
  }

  // Function to delete a note
  function deleteNote(noteId) {
    fetch(`/api/notes/${noteId}`, {
      method: 'DELETE'
    })
    .then(() => fetchNotes())
    .catch(error => console.error('Error deleting note:', error));
  }

  // Function to confirm deletion of a note
  function deleteNoteConfirm(noteId) {
    if (confirm('Are you sure you want to delete this note?')) {
      deleteNote(noteId);
    }
  }

  // Function to populate form for editing a note
  function editNoteForm(note) {
    noteIdInput.value = note.id;
    noteTitleInput.value = note.title;
    noteContentInput.value = note.content;

    editingNoteId = note.id;

    addNoteButton.style.display = 'none';
    updateNoteButton.style.display = 'inline-block';
    deleteNoteButton.style.display = 'inline-block';
    cancelEditButton.style.display = 'inline-block';
  }

  // Function to reset form and clear editing state
  function resetForm() {
    noteIdInput.value = '';
    noteTitleInput.value = '';
    noteContentInput.value = '';

    editingNoteId = null;

    addNoteButton.style.display = 'inline-block';
    updateNoteButton.style.display = 'none';
    deleteNoteButton.style.display = 'none';
    cancelEditButton.style.display = 'none';
  }

  // Function to handle canceling edit mode
  cancelEditButton.addEventListener('click', function() {
    resetForm();
  });

  // Initial fetch of notes when page loads
  fetchNotes();
});
