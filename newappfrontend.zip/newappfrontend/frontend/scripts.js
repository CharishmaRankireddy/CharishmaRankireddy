// scripts.js

// Function to handle form submissions using Fetch API
async function handleFormSubmit(url, formData) {
    try {
      const response = await fetch(url, {
        method: 'POST',
        body: formData
      });
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return await response.json(); // Assuming backend returns JSON data
    } catch (error) {
      console.error('Error:', error);
      // Handle error (e.g., display error message)
    }
  }
  
  // Function to handle login form submission
  document.getElementById('loginForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const url = '/api/login'; // Replace with your backend API endpoint for login
    const responseData = await handleFormSubmit(url, formData);
    console.log('Login response:', responseData);
    // Handle login response (e.g., redirect to notes page on success)
  });
  
  // Function to handle register form submission
  document.getElementById('registerForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const url = '/api/register'; // Replace with your backend API endpoint for registration
    const responseData = await handleFormSubmit(url, formData);
    console.log('Register response:', responseData);
    // Handle registration response (e.g., show success message)
  });
  
  // Function to handle add note form submission
  document.getElementById('addNoteForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const formData = new FormData(this);
    const noteId = formData.get('noteId');
    const url = noteId ? `/api/notes/update/${noteId}` : '/api/notes/add'; // Replace with your backend API endpoint for adding/updating notes
    const responseData = await handleFormSubmit(url, formData);
    console.log('Add/Update note response:', responseData);
    // Handle add/update note response (e.g., refresh notes list)
    fetchNotes(); // Example function to fetch and display notes after adding/updating
    resetForm(); // Reset form after submission
  });
  
  // Function to fetch and display notes (example)
  async function fetchNotes() {
    const url = '/api/notes'; // Replace with your backend API endpoint for fetching notes
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const notesData = await response.json(); // Assuming backend returns JSON array of notes
      const notesList = document.getElementById('notesList');
      notesList.innerHTML = ''; // Clear previous notes
      notesData.forEach(note => {
        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
          <div class="card-body">
            <h5 class="card-title">${note.title}</h5>
            <p class="card-text">${note.content}</p>
            <button class="btn btn-secondary btn-sm" onclick="editNote(${note.id})">Edit</button>
            <button class="btn btn-danger btn-sm" onclick="deleteNote(${note.id})">Delete</button>
          </div>
        `;
        notesList.appendChild(card);
      });
    } catch (error) {
      console.error('Error:', error);
      // Handle error (e.g., display error message)
    }
  }
  
  // Function to reset the form
  function resetForm() {
    document.getElementById('addNoteForm').reset();
    document.getElementById('noteId').value = '';
    document.getElementById('addNoteButton').style.display = 'block';
    document.getElementById('updateNoteButton').style.display = 'none';
    document.getElementById('cancelEditButton').style.display = 'none';
  }
  
  // Function to edit a note
  function editNote(noteId) {
    const noteTitle = document.querySelector(`.card[data-id="${noteId}"] .card-title`).innerText;
    const noteContent = document.querySelector(`.card[data-id="${noteId}"] .card-text`).innerText;
    document.getElementById('noteTitle').value = noteTitle;
    document.getElementById('noteContent').value = noteContent;
    document.getElementById('noteId').value = noteId;
    document.getElementById('addNoteButton').style.display = 'none';
    document.getElementById('updateNoteButton').style.display = 'block';
    document.getElementById('cancelEditButton').style.display = 'block';
  }
  
  // Function to delete a note
  async function deleteNote(noteId) {
    const url = `/api/notes/delete/${noteId}`; // Replace with your backend API endpoint for deleting notes
    try {
      const response = await fetch(url, { method: 'DELETE' });
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      console.log('Delete note response:', await response.json());
      // Handle delete note response (e.g., refresh notes list)
      fetchNotes(); // Example function to fetch and display notes after deleting
    } catch (error) {
      console.error('Error:', error);
      // Handle error (e.g., display error message)
    }
  }
  
  // Initial call to fetch and display notes when page loads
  document.addEventListener('DOMContentLoaded', function() {
    fetchNotes();
    document.getElementById('cancelEditButton').addEventListener('click', resetForm);
  });
  