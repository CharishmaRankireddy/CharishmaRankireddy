from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorClient
from .models import UserIn, NoteIn
from .database import get_database
from .auth import get_password_hash

db = get_database()

async def get_user_by_username(username: str):
    return await db["users"].find_one({"username": username})

async def create_user(user: UserIn):
    user_dict = user.dict()
    user_dict["password"] = get_password_hash(user_dict["password"])
    await db["users"].insert_one(user_dict)
    user_dict["id"] = str(user_dict["_id"])
    return user_dict

async def get_note_by_id(note_id: str):
    return await db["notes"].find_one({"_id": ObjectId(note_id)})

async def create_note_for_user(user, note: NoteIn):
    note_dict = note.dict()
    note_dict["user_id"] = user.id
    await db["notes"].insert_one(note_dict)
    note_dict["id"] = str(note_dict["_id"])
    return note_dict

async def get_notes(user, skip: int = 0, limit: int = 10):
    cursor = db["notes"].find({"user_id": user.id}).skip(skip).limit(limit)
    return [note async for note in cursor]

async def update_note(note_id: str, note: NoteIn):
    await db["notes"].update_one({"_id": ObjectId(note_id)}, {"$set": note.dict()})
    return await get_note_by_id(note_id)

async def delete_note(note_id: str):
    await db["notes"].delete_one({"_id": ObjectId(note_id)})
    return {"id": note_id}
