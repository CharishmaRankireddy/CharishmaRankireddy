# backend/database.py
from motor.motor_asyncio import AsyncIOMotorClient
from bson import ObjectId

class MongoDB:
    def __init__(self, uri, db_name):
        self.client = AsyncIOMotorClient(uri)
        self.db = self.client[db_name]

    def get_db(self):
        return self.db

mongo_client = MongoDB("mongodb://localhost:27017", "note_app")
database = mongo_client.get_db()

def to_object_id(id: str) -> ObjectId:
    return ObjectId(id)
