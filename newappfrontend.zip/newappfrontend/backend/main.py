from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
from . import auth, crud, models, database

app = FastAPI()

# Allow CORS
origins = ["http://localhost:8000"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# User registration
@app.post("/auth/register", response_model=models.UserOut)
async def register(user: models.UserIn):
    db_user = await crud.get_user_by_username(user.username)
    if db_user:
        raise HTTPException(status_code=400, detail="Username already registered")
    return await crud.create_user(user)

# User login
@app.post("/auth/token", response_model=models.Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = await auth.authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    access_token = auth.create_access_token(data={"sub": user.username})
    return {"access_token": access_token, "token_type": "bearer"}

# Create a note
@app.post("/notes/", response_model=models.Note)
async def create_note(note: models.NoteIn, current_user: models.User = Depends(auth.get_current_user)):
    return await crud.create_note_for_user(current_user, note)

# Read notes
@app.get("/notes/", response_model=List[models.Note])
async def read_notes(skip: int = 0, limit: int = 10, current_user: models.User = Depends(auth.get_current_user)):
    notes = await crud.get_notes(current_user, skip=skip, limit=limit)
    return notes

# Update a note
@app.put("/notes/{note_id}", response_model=models.Note)
async def update_note(note_id: str, note: models.NoteIn, current_user: models.User = Depends(auth.get_current_user)):
    db_note = await crud.get_note_by_id(note_id)
    if db_note is None or db_note.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Note not found")
    return await crud.update_note(note_id, note)

# Delete a note
@app.delete("/notes/{note_id}", response_model=models.Note)
async def delete_note(note_id: str, current_user: models.User = Depends(auth.get_current_user)):
    db_note = await crud.get_note_by_id(note_id)
    if db_note is None or db_note.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Note not found")
    return await crud.delete_note(note_id)
